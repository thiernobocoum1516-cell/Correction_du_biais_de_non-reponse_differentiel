# =============================================================================
# 01_import_nettoyage.R
# Importation du fichier Stata et sélection des variables utiles.
# On élimine les lignes où la dépense par tête est manquante (critère
# d'exploitabilité pour la simulation du biais).
# Le résultat (4621 ménages complets) est sauvegardé pour les étapes suivantes.
# =============================================================================

# ---- 1. Importation depuis le fichier Stata ----
df_raw <- read_dta("data/percapita_expenditure.dta") 

# ---- 2. Variables retenues ----
# percapita_exp : dépense par tête (proxy du revenu)
# hhsize        : taille du ménage
# urbrur        : milieu de résidence (1 = urbain, 2 = rural)
# age           : âge du chef de ménage
colonnes_utiles <- c("percapita_exp", "hhsize", "urbrur", "age")

# ---- 3. Nettoyage ----
df <- df_raw %>%
  select(all_of(colonnes_utiles)) %>%   # garder uniquement les colonnes utiles
  filter(!is.na(percapita_exp))         # supprimer les valeurs manquantes de la variable clé

cat("Nombre de ménages complets après nettoyage :", nrow(df), "\n")

# ---- 4. Sauvegarde pour utilisation ultérieure ----
saveRDS(df, "data/df_clean.rds")