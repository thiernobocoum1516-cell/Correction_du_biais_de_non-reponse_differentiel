# =============================================================================
# 03_simulation_biais.R
# Simulation d'un biais de non‑réponse MNAR en forme de U inversé.
# La probabilité de réponse dépend quadratiquement du log‑revenu centré‑réduit.
# L'intercept est ajusté pour obtenir un taux de non‑réponse de 34%.
# Un graphique de la probabilité de réponse en fonction du revenu est produit.
# =============================================================================

# ---- 1. Chargement de la base bootstrapée ----
df_boot <- readRDS("data/df_boot.rds") 

# ---- 2. Transformation du revenu : log et centrage‑réduction ----
df_sim <- df_boot %>%
  mutate(
    log_rev   = log(percapita_exp + 1),
    log_rev_sc = as.numeric(scale(log_rev))   # moyenne 0, écart-type 1
  )

# ---- 3. Coefficients de forme de la probabilité de réponse ----
b1 <- 1.5   # coefficient linéaire : positif → probabilité augmente près de la moyenne
b2 <- -2    # coefficient quadratique : négatif → chute aux extrêmes (U inversé)

# ---- 4. Recherche de l'intercept pour 34% de non‑réponse (66% de répondants) ----
f <- function(a) {
  p <- plogis(a + b1 * df_sim$log_rev_sc + b2 * df_sim$log_rev_sc^2)
  mean(p) - 0.66
}
sol <- uniroot(f, c(-5, 5))   # résolution numérique
a0 <- sol$root
cat("Intercept optimal :", round(a0, 4), "\n")

# ---- 5. Calcul des probabilités de réponse individuelles ----
df_sim <- df_sim %>%
  mutate(
    logit_p  = a0 + b1 * log_rev_sc + b2 * log_rev_sc^2,
    p_reponse = plogis(logit_p)
  )

# ---- 6. Tirage aléatoire du statut de réponse ----
set.seed(2025)
df_sim <- df_sim %>%
  mutate(reponse = rbinom(n(), 1, p_reponse))

cat("Taux de non‑réponse simulé :", round(1 - mean(df_sim$reponse), 4), "\n")

# ---- 7. Graphique de la probabilité de réponse ----
graphe_biais <- ggplot(df_sim, aes(x = percapita_exp, y = p_reponse)) +
  geom_point(alpha = 0.2, color = "skyblue") +           # bleu plus clair
  geom_smooth(se = FALSE, color = "black", linewidth = 1.2, method = "loess") +
  scale_x_log10() +
  labs(title    = "Probabilité de réponse en fonction du revenu",
       subtitle = "Mécanisme MNAR en U inversé (34 % de non‑réponse)",
       x        = "Dépense par tête (échelle log)",
       y        = "Probabilité de réponse",
       caption  = "Source : Enquête ménage Ghana (GLSS), calculs de l'auteur") +
  theme_minimal() +
  theme(plot.title    = element_text(hjust = 0.5),       # titre centré
        plot.subtitle = element_text(hjust = 0.5))       # sous titre centré

ggsave("outputs/graphe_biais.pdf", graphe_biais, width = 7, height = 5)
saveRDS(graphe_biais, "data/graphe_biais.rds")

# ---- 8. Sauvegarde de la population simulée ----
saveRDS(df_sim, "data/df_sim.rds") 