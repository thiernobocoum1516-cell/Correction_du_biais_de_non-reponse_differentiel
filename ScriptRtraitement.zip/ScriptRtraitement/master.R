# =============================================================================
# master.R  (version corrigée)
# Script maître pour exécution interactive (hors knit).
# Pour le rapport, utiliser scriptRtraitement.R à la place.
# =============================================================================

if (!dir.exists("data"))    dir.create("data",    recursive = TRUE)
if (!dir.exists("outputs")) dir.create("outputs", recursive = TRUE)

source("00_setup.R")
source("01_import_nettoyage.R")
source("02_bootstrap_bruitage.R")
source("03_simulation_biais.R")
source("04_ipw.R")
source("05_hotdeck.R")
source("06_manski.R")
source("07_analyse_sensibilite.R")

cat("\nPipeline terminé avec succès.\n")
