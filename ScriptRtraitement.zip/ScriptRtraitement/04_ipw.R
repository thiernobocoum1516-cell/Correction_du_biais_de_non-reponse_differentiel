# =============================================================================
# 04_ipw.R
# Correction du biais de non‑réponse par la méthode Inverse Probability Weighting.
# Un modèle logistique pénalisé (Firth) estime la probabilité de réponse.
# Les poids sont winsorisés au 99e centile pour stabiliser l'estimateur.
# La moyenne, la médiane et la variance corrigées sont calculées via le package survey.
# =============================================================================

# ---- 1. Chargement de la population simulée ----
df_sim <- readRDS("data/df_sim.rds")

# ---- 2. Suppression des NA résiduels sur les variables explicatives ----
vars_modele <- c("log_rev_sc", "urbrur", "hhsize", "age") 
df_sim <- df_sim[complete.cases(df_sim[, vars_modele]), ]

# Mise à jour des sous‑ensembles répondants / non‑répondants
df_ech    <- df_sim[df_sim$reponse == 1, ]
df_nonrep <- df_sim[df_sim$reponse == 0, ]

# ---- 3. Modèle de réponse : logistique pénalisée (Firth) ----
# La pénalisation évite les problèmes de séparation quasi‑parfaite
modele_ipw <- glm(
  reponse ~ log_rev_sc + I(log_rev_sc^2) + factor(urbrur) + hhsize + age,
  family = binomial,
  data   = df_sim,          # entraîné sur TOUTE la population (répondants + non-répondants)
  method = "brglmFit"       # estimation par vraisemblance pénalisée (Firth)
)

# ---- 4. Probabilités prédites et poids IPW ----
df_sim$p_ipw <- predict(modele_ipw, newdata = df_sim, type = "response")
df_sim$w_ipw <- 1 / df_sim$p_ipw

# ---- 5. Winsorisation des poids (limitation des valeurs extrêmes) ----
seuil_w <- quantile(df_sim$w_ipw, 0.99, na.rm = TRUE)
df_sim$w_ipw_winsor <- ifelse(df_sim$w_ipw > seuil_w, seuil_w, df_sim$w_ipw)

# ---- 6. Transfert des poids vers df_ech (répondants uniquement) ----
# svydesign ne s'applique qu'aux répondants ; il faut que w_ipw_winsor
# soit présent dans ce sous-ensemble.
df_ech <- df_sim[df_sim$reponse == 1, ]

# ---- 7. Plan de sondage et estimation des moments corrigés ----
design_ipw <- svydesign(ids = ~1, weights = ~w_ipw_winsor, data = df_ech)

moy_ipw <- svymean(~percapita_exp, design_ipw)
med_ipw <- svyquantile(~percapita_exp, design_ipw, quantiles = 0.5)
var_ipw <- svyvar(~percapita_exp, design_ipw)

# ---- 8. Sauvegarde des résultats ----
resultats_ipw <- list(
  moyenne  = as.numeric(coef(moy_ipw)),
  mediane  = as.numeric(coef(med_ipw)),
  variance = as.numeric(var_ipw)
)
saveRDS(resultats_ipw, "data/resultats_ipw.rds")
saveRDS(df_sim, "data/df_sim.rds")   # mise à jour (contient p_ipw, w_ipw, w_ipw_winsor)

cat("IPW terminé. Moyenne corrigée :", resultats_ipw$moyenne, "\n")
