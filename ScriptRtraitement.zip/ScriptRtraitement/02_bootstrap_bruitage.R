# =============================================================================
# 02_bootstrap_bruitage.R
# Extension de l'échantillon à 5000 ménages par bootstrap contrôlé.
# Chaque ménage d'origine est présent au maximum deux fois.
# Un bruit gaussien très faible est ajouté uniquement aux doublons pour
# éviter toute duplication exacte, sans altérer la distribution.
# Un graphique de densité et un tableau comparatif sont produits pour
# vérifier l'absence d'impact du bruitage.
# =============================================================================

# ---- 1. Charger la base nettoyée ----
df <- readRDS("data/df_clean.rds")

# ---- 2. Paramètres du bootstrap contrôlé ----
n_original <- nrow(df)               # 4621
n_cible    <- 5000
n_extra    <- n_cible - n_original   # 379 lignes supplémentaires

set.seed(123)   # reproductibilité

# Tirage sans remise des indices supplémentaires
lignes_extra <- sample(1:n_original, n_extra, replace = FALSE)

# Vecteur d'index final : chaque ligne d'origine apparaît au moins une fois,
# les 379 lignes supplémentaires apparaissent deux fois.
idx <- c(1:n_original, lignes_extra)
df_boot <- df[idx, ]

# ---- 3. Détection des doublons exacts ----
colonnes_utiles <- c("percapita_exp", "hhsize", "urbrur", "age")
df_boot$est_doublon <- duplicated(df_boot[, colonnes_utiles])

# ---- 4. Bruitage ciblé (uniquement sur les doublons) ----
bruit_cols <- c("percapita_exp", "hhsize", "age")
for (col in bruit_cols) {
  # Ecart-type du bruit : 5% de l'écart-type de la variable
  sd_col <- sd(df_boot[[col]], na.rm = TRUE) * 0.05
  # Ajout d'un bruit gaussien centré sur zéro aux seuls doublons
  df_boot[[col]] <- ifelse(
    df_boot$est_doublon,
    df_boot[[col]] + rnorm(nrow(df_boot), 0, sd_col),
    df_boot[[col]]
  )
}

# ---- 5. Correction des valeurs devenues négatives (conservatisme) ----
df_boot <- df_boot %>%
  mutate(across(all_of(bruit_cols), ~ ifelse(.x < 0, 0, .x))) %>%
  select(-est_doublon)   # suppression de la colonne auxiliaire

# ---- 6. Vérification : aucun doublon exact ne doit persister ----
stopifnot(!any(duplicated(df_boot[, colonnes_utiles])))
cat("Nombre final d'observations :", nrow(df_boot), "\n")
cat("Aucun doublon exact détecté.\n")

# ---- 7. Graphique comparatif avant / après bruitage ----
df_comp <- rbind(
  data.frame(percapita = df$percapita_exp, Type = "Avant bruitage"),
  data.frame(percapita = df_boot$percapita_exp, Type = "Après bruitage")
)

graphe_bruitage <- ggplot(df_comp, aes(x = percapita, color = Type, fill = Type)) +
  geom_density(alpha = 0.3, linewidth = 1) +
  scale_color_manual(values = c("Après bruitage" = "black", "Avant bruitage" = "skyblue")) +
  scale_fill_manual(values = c("Après bruitage" = "black", "Avant bruitage" = "skyblue")) +
  scale_x_log10() +
  labs(title    = "Impact du bruitage sur la distribution des dépenses",
       x        = "Dépense par tête (échelle log)",
       y        = "Densité",
       caption  = "Source : Enquête ménage Ghana (GLSS), calculs de l'auteur") +
  theme_minimal() +
  theme(legend.position = "bottom",
        plot.title       = element_text(hjust = 0.5))

# Sauvegarde du graphique pour le rapport
ggsave("outputs/graphe_bruitage.pdf", graphe_bruitage, width = 7, height = 5)
saveRDS(graphe_bruitage, "data/graphe_bruitage.rds")

# ---- 8. Tableau comparatif des statistiques ----
# On force l'ordre des niveaux pour que "Avant bruitage" apparaisse en premier
df_comp$Type <- factor(df_comp$Type, levels = c("Avant bruitage", "Après bruitage"))

table_stats <- df_comp %>%
  group_by(Type) %>%
  summarise(
    Effectif  = n(),
    Moyenne   = mean(percapita),
    Ecart_type = sd(percapita),
    Minimum   = min(percapita),
    Q1        = quantile(percapita, 0.25),
    Médiane   = median(percapita),
    Q3        = quantile(percapita, 0.75),
    Maximum   = max(percapita)
  )
print(table_stats)
saveRDS(table_stats, "data/table_stats.rds")

# ---- 9. Sauvegarde de la base finale ----
saveRDS(df_boot, "data/df_boot.rds")