# =============================================================================
# 00_setup.R
# Chargement des packages nécessaires à l'ensemble du projet.
# Tous les scripts suivants supposent que ce fichier a été exécuté.
# =============================================================================

# Importation de données Stata
library(haven)

# Manipulation de données
library(dplyr)

# Graphiques
library(ggplot2)

# Analyse de données pondérées (plans de sondage complexes)
library(survey)

# Régression logistique pénalisée (méthode de Firth) pour gérer la séparation
library(brglm2)

message("Packages chargés avec succès.")
