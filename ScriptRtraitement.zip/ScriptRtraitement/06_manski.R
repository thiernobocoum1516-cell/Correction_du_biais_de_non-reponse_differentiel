# =============================================================================
# 06_manski.R
# Calcul des bornes de Manski pour la moyenne de la dépense par tête.
# Aucune hypothèse n'est faite sur les non‑répondants.
# Borne inférieure : tous les non‑répondants auraient la plus petite valeur observée.
# Borne supérieure : tous les non‑répondants auraient la plus grande valeur observée.
# =============================================================================

# ---- 1. Chargement de la population simulée ----
df_sim <- readRDS("data/df_sim.rds")

# ---- 2. Valeurs extrêmes observées ----
y_min <- min(df_sim$percapita_exp, na.rm = TRUE)
y_max <- max(df_sim$percapita_exp, na.rm = TRUE)

# ---- 3. Effectifs et moyenne des répondants ----
n_tot      <- nrow(df_sim)
n_rep      <- sum(df_sim$reponse)
y_bar_rep  <- mean(df_sim$percapita_exp[df_sim$reponse == 1])

# ---- 4. Bornes ----
born_inf <- (n_rep * y_bar_rep + (n_tot - n_rep) * y_min) / n_tot
born_sup <- (n_rep * y_bar_rep + (n_tot - n_rep) * y_max) / n_tot

bornes <- c(inf = born_inf, sup = born_sup)
cat("Bornes de Manski : [", round(born_inf, 2), ",", round(born_sup, 2), "]\n")

# ---- 5. Sauvegarde ----
saveRDS(bornes, "data/bornes_manski.rds")