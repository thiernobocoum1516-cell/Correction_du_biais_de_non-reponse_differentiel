# =============================================================================
# 07_analyse_sensibilite.R
# Compilation des résultats de toutes les méthodes et analyse de sensibilité.
# Un tableau récapitulatif (moyenne, médiane, variance) et un graphique
# comparatif des moyennes sont produits.
# =============================================================================

# ---- 1. Chargement de tous les résultats intermédiaires ----
df_sim       <- readRDS("data/df_sim.rds")
df_sim_hd    <- readRDS("data/df_sim_hd.rds")
res_ipw      <- readRDS("data/resultats_ipw.rds")
bornes       <- readRDS("data/bornes_manski.rds")

# ---- 2. Calcul des statistiques vraies, naïves et corrigées ----

# Moyennes
vraie_moy <- mean(df_sim$percapita_exp)
naive_moy <- mean(df_sim$percapita_exp[df_sim$reponse == 1])
ipw_moy   <- res_ipw$moyenne
hd_moy    <- mean(df_sim_hd$percapita_hd, na.rm = TRUE)

# Médianes
vraie_med <- median(df_sim$percapita_exp)
naive_med <- median(df_sim$percapita_exp[df_sim$reponse == 1])
ipw_med   <- res_ipw$mediane
hd_med    <- median(df_sim_hd$percapita_hd, na.rm = TRUE)

# Variances
vraie_var <- var(df_sim$percapita_exp)
naive_var <- var(df_sim$percapita_exp[df_sim$reponse == 1])
ipw_var   <- res_ipw$variance
hd_var    <- var(df_sim_hd$percapita_hd, na.rm = TRUE)

# ---- 3. Constitution du tableau récapitulatif ----
resultats_finaux <- data.frame(
  Methode  = c("Vraie", "Naïve", "IPW", "Hot‑deck", "Manski Inf", "Manski Sup"),
  Moyenne  = c(vraie_moy, naive_moy, ipw_moy, hd_moy, bornes["inf"], bornes["sup"]),
  Médiane  = c(vraie_med, naive_med, ipw_med, hd_med, NA, NA),
  Variance = c(vraie_var, naive_var, ipw_var, hd_var, NA, NA)
)

print(resultats_finaux)
saveRDS(resultats_finaux, "data/resultats_finaux.rds")

# ---- 4. Graphique comparatif des moyennes (hors bornes de Manski) ----
library(dplyr)
library(tidyr)
library(ggplot2)


# Données : 4 premières lignes (Vraie, Naïve, IPW, Hot‑deck)
library(dplyr)
library(tidyr)
library(ggplot2)


# ---- 1. Données de base et référence ----
df_plot <- resultats_finaux[1:4, c("Methode", "Moyenne", "Médiane", "Variance")]

vraies <- df_plot %>%
  filter(Methode == "Vraie") %>%
  pivot_longer(-Methode, names_to = "Statistique", values_to = "Vraie") %>%
  select(Statistique, Vraie)

# ---- 2. Format long, écarts et identification de la meilleure correction par indicateur ----
df_long <- df_plot %>%
  pivot_longer(-Methode, names_to = "Statistique", values_to = "Valeur") %>%
  left_join(vraies, by = "Statistique") %>%
  mutate(Ecart = abs(Valeur - Vraie))

# Meilleure méthode corrigée (hors Vraie) pour chaque statistique
meilleure_par_stat <- df_long %>%
  filter(Methode != "Vraie") %>%
  group_by(Statistique) %>%
  slice_min(Ecart) %>%
  ungroup() %>%
  mutate(est_meilleure = TRUE) %>%
  select(Statistique, Methode, est_meilleure)

# ---- 3. Fusion avec les données longues et création d'une étiquette unique ----
df_long <- df_long %>%
  left_join(meilleure_par_stat, by = c("Statistique", "Methode")) %>%
  replace_na(list(est_meilleure = FALSE)) %>%
  mutate(
    # Étiquette : valeur avec étoile si meilleure, sinon valeur simple
    Label = if_else(est_meilleure,
                    paste0(round(Valeur, 1), " ★"),
                    as.character(round(Valeur, 1))),
    # Gras pour la meilleure, normal sinon
    Fontface = if_else(est_meilleure, "bold", "plain")
  )

# ---- 4. Graphique sans superposition ----
graphe_complet <- ggplot() +
  # Barres
  geom_col(
    data = df_long,
    aes(x = Methode, y = Valeur, fill = Methode == "Vraie"),
    width = 0.7
  ) +
  # Ligne de référence (vraie valeur)
  geom_hline(
    data = vraies,
    aes(yintercept = Vraie),
    linetype = "dashed", color = "skyblue4", linewidth = 0.8
  ) +
  # Unique couche d'étiquettes avec le symbole distinctif
  geom_text(
    data = df_long,
    aes(x = Methode, y = Valeur, label = Label, fontface = Fontface),
    vjust = -0.3, size = 3.5, color = "black"
  ) +
  facet_wrap(~ Statistique, scales = "free_y") +
  scale_fill_manual(values = c("TRUE" = "skyblue4", "FALSE" = "skyblue"),
                    guide = "none") +
  labs(
    title    = "Comparaison des indicateurs par méthode de correction",
    subtitle = "★ désigne la méthode corrigée la plus proche de la vraie valeur",
    caption  = "Source : Enquête ménage Ghana (GLSS), calculs de l'auteur"
  ) +
  theme_minimal() +
  theme(
    plot.title    = element_text(hjust = 0.5),
    plot.subtitle = element_text(hjust = 0.5),
    legend.position = "none"
  )

# ---- 5. Sauvegarde ----
ggsave("outputs/graphe_complet.pdf", graphe_complet, width = 10, height = 6)
saveRDS(graphe_complet, "data/graphe_complet.rds")