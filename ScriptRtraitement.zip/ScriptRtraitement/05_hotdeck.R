# =============================================================================
# 05_hotdeck.R
# Imputation par hot‑deck stratifié.
# Pour chaque non‑répondant, un donneur est tiré aléatoirement parmi les
# répondants de la même strate (croisement milieu × classe de taille du ménage).
# Cette méthode ne modélise pas la probabilité de réponse, contournant ainsi
# le problème de séparation quasi‑parfaite rencontré avec l'IPW.
# =============================================================================
  
# ---- 1. Chargement de la population simulée ----
df_sim <- readRDS("data/df_sim.rds")

# ---- 2. Création de la variable de strate ----
df_sim <- df_sim %>%
  mutate(
    taille_cl = cut(hhsize,
                    breaks = c(1, 2, 4, 6, 8, Inf),
                    include.lowest = TRUE,
                    right = FALSE),
    strate = paste(urbrur, taille_cl, sep = "_")
  )

# ---- 3. Fonction d'imputation hot‑deck ----
hotdeck_impute <- function(data, var_imp, var_strate, var_reponse) {
  out <- data[[var_imp]]
  for (i in which(data[[var_reponse]] == 0)) {
    # Identifier les donneurs potentiels (même strate, répondants)
    donneurs <- which(data[[var_strate]] == data[[var_strate]][i] & data[[var_reponse]] == 1)
    if (length(donneurs) > 0) {
      # Tirage aléatoire d'un donneur
      out[i] <- data[[var_imp]][sample(donneurs, 1)]
    }
    # Si aucun donneur, on laisse NA (situation rare)
  }
  return(out)
}

# ---- 4. Application de l'imputation ----
df_sim$percapita_hd <- hotdeck_impute(df_sim, "percapita_exp", "strate", "reponse")

# ---- 5. Sauvegarde de la base complétée ----
saveRDS(df_sim, "data/df_sim_hd.rds")
cat("Hot‑deck terminé.\n")