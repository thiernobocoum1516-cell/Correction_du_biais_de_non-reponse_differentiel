# =============================================================================
# scriptRtraitement.R  -  Point d'entree unique pour le rapport Rmd
# =============================================================================

if (!dir.exists("data"))    dir.create("data",    recursive = TRUE)
if (!dir.exists("outputs")) dir.create("outputs", recursive = TRUE)

source("00_setup.R",               echo = FALSE, local = FALSE)
source("01_import_nettoyage.R",    echo = FALSE, local = FALSE)
source("02_bootstrap_bruitage.R",  echo = FALSE, local = FALSE)
source("03_simulation_biais.R",    echo = FALSE, local = FALSE)

# ---- IPW corrige directement (contourne le bug de 04_ipw.R) ----------------
df_sim <- readRDS("data/df_sim.rds")
vars_modele <- c("log_rev_sc", "urbrur", "hhsize", "age")
df_sim <- df_sim[complete.cases(df_sim[, vars_modele]), ]

modele_ipw <- glm(
  reponse ~ log_rev_sc + I(log_rev_sc^2) + factor(urbrur) + hhsize + age,
  family = binomial, data = df_sim, method = "brglmFit"
)
df_sim$p_ipw        <- predict(modele_ipw, newdata = df_sim, type = "response")
df_sim$w_ipw        <- 1 / df_sim$p_ipw
seuil_w             <- quantile(df_sim$w_ipw, 0.99, na.rm = TRUE)
df_sim$w_ipw_winsor <- ifelse(df_sim$w_ipw > seuil_w, seuil_w, df_sim$w_ipw)
df_ech              <- df_sim[df_sim$reponse == 1, ]

design_ipw <- survey::svydesign(ids = ~1, weights = ~w_ipw_winsor, data = df_ech)
moy_ipw    <- survey::svymean(~percapita_exp, design_ipw)
med_ipw    <- survey::svyquantile(~percapita_exp, design_ipw, quantiles = 0.5)
var_ipw    <- survey::svyvar(~percapita_exp, design_ipw)

resultats_ipw <- list(
  moyenne  = as.numeric(coef(moy_ipw)),
  mediane  = as.numeric(coef(med_ipw)),
  variance = as.numeric(var_ipw)
)
saveRDS(resultats_ipw, "data/resultats_ipw.rds")
saveRDS(df_sim,        "data/df_sim.rds")
cat("IPW termine. Moyenne :", resultats_ipw$moyenne, "\n")
# ----------------------------------------------------------------------------

source("05_hotdeck.R",             echo = FALSE, local = FALSE)
source("06_manski.R",              echo = FALSE, local = FALSE)
source("07_analyse_sensibilite.R", echo = FALSE, local = FALSE)

# Chargement defensif
charger <- function(nom, chemin) {
  if (!exists(nom, envir = .GlobalEnv) && file.exists(chemin))
    assign(nom, readRDS(chemin), envir = .GlobalEnv)
}
charger("graphe_bruitage",  "data/graphe_bruitage.rds")
charger("table_stats",      "data/table_stats.rds")
charger("graphe_biais",     "data/graphe_biais.rds")
charger("resultats_finaux", "data/resultats_finaux.rds")
charger("graphe_compar",    "data/graphe_compar.rds")
charger("bornes",           "data/bornes_manski.rds")
charger("resultats_ipw",    "data/resultats_ipw.rds")

message("=== Pipeline termine avec succes. ===")
